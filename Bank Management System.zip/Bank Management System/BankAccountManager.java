import java.io.*;
import java.util.*;

class BankAccount {
    private String accountNumber;
    private String accountHolderName;
    private double balance;

    public BankAccount() {
        this.balance = 0.0;
    }

    public BankAccount(String accNumber, String holderName, double initialBalance) {
        this.accountNumber = accNumber;
        this.accountHolderName = holderName;
        this.balance = initialBalance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    public void setAccountHolderName(String holderName) {
        this.accountHolderName = holderName;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient funds or invalid withdrawal amount.");
        }
    }

    public void display() {
        System.out.printf("Account Number: %s%n", accountNumber);
        System.out.printf("Account Holder: %s%n", accountHolderName);
        System.out.printf("Balance: Rs. %.2f%n", balance);
    }

    public void saveToFile(PrintWriter out) {
        out.println(accountNumber);
        out.println(accountHolderName);
        out.println(balance);
    }

    public void loadFromFile(Scanner in) {
        this.accountNumber = in.nextLine();
        this.accountHolderName = in.nextLine();
        if (in.hasNextDouble()) {
            this.balance = in.nextDouble();
            in.nextLine(); // consume leftover newline
        }
    }
}

public class BankAccountManager {
    private static ArrayList<BankAccount> accounts = new ArrayList<>();

    public static void main(String[] args) {
        loadAccountsFromFile();

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nBank Management System");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Display Account");
            System.out.println("5. Save and Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    createAccount(scanner);
                    break;
                case 2:
                    depositToAccount(scanner);
                    break;
                case 3:
                    withdrawFromAccount(scanner);
                    break;
                case 4:
                    displayAccount(scanner);
                    break;
                case 5:
                    saveAccountsToFile();
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void createAccount(Scanner scanner) {
        System.out.print("Enter account number: ");
        String accNumber = scanner.nextLine();

        System.out.print("Enter account holder's name: ");
        String holderName = scanner.nextLine();

        System.out.print("Enter initial balance: ");
        double initialBalance = scanner.nextDouble();
        scanner.nextLine(); // consume newline

        BankAccount account = new BankAccount(accNumber, holderName, initialBalance);
        accounts.add(account);

        System.out.println("Account created successfully.");
    }

    private static void depositToAccount(Scanner scanner) {
        System.out.print("Enter account number to deposit into: ");
        String accNumber = scanner.nextLine();

        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        for (int i = 0; i < accounts.size(); i++) {
            BankAccount acc = accounts.get(i);
            if (acc.getAccountNumber().equals(accNumber)) {
                acc.deposit(amount);
                System.out.println("Deposit successful.");
                return;
            }
        }

        System.out.println("Account not found.");
    }

    private static void withdrawFromAccount(Scanner scanner) {
        System.out.print("Enter account number to withdraw from: ");
        String accNumber = scanner.nextLine();

        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        for (int i = 0; i < accounts.size(); i++) {
            BankAccount acc = accounts.get(i);
            if (acc.getAccountNumber().equals(accNumber)) {
                acc.withdraw(amount);
                System.out.println("Withdrawal successful.");
                return;
            }
        }

        System.out.println("Account not found.");
    }

    private static void displayAccount(Scanner scanner) {
        System.out.print("Enter account number to display: ");
        String accNumber = scanner.nextLine();

        for (int i = 0; i < accounts.size(); i++) {
            BankAccount acc = accounts.get(i);
            if (acc.getAccountNumber().equals(accNumber)) {
                acc.display();
                return;
            }
        }

        System.out.println("Account not found.");
    }

    private static void saveAccountsToFile() {
        try (PrintWriter out = new PrintWriter("accounts.txt")) {
            for (int i = 0; i < accounts.size(); i++) {
                BankAccount acc = accounts.get(i);
                acc.saveToFile(out);
            }
            System.out.println("Accounts saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving accounts: " + e.getMessage());
        }
    }

    private static void loadAccountsFromFile() {
        File file = new File("accounts.txt");
        if (!file.exists()) return;

        try (Scanner in = new Scanner(file)) {
            while (in.hasNextLine()) {
                BankAccount acc = new BankAccount();
                acc.loadFromFile(in);
                accounts.add(acc);
            }
            System.out.println("Accounts loaded from file.");
        } catch (IOException e) {
            System.out.println("Error loading accounts: " + e.getMessage());
        }
    }
}
